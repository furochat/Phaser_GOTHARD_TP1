﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacBehaviour : MonoBehaviour
{

    public Rigidbody2D rb;
    public float vitesse;
    public float maxJump;
    private bool isGrounded = false;

    // Initialisation
    void Start()
    {
        SetVelocity(vitesse, 0);
       

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("space") && isGrounded)
        {
            Jump();
        }
    }

    void Jump()
    {
        rb.velocity += new Vector2(0, maxJump);
    }
    // Lorsqu'il touche le sol compareTag
    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;

        }
    }

    // Lorsqu'il quitte le sol
    void OnCollisionExit2D(Collision2D col)
    {
        if (col.gameObject.CompareTag("Ground"))
        {
            isGrounded = false;

        }

    }
     void SetVelocity(float xVelocity, float yVelocity){
        rb.velocity = new Vector2(0, 0);
        rb.velocity = new Vector2(xVelocity, yVelocity);
    }


    //Lorsqu'il entre en collision avec un obstacle
    // Coroutine appeler une fonction qui peut se mettre en pause
    private void OnTriggerEnter2D(Collider2D col){
        if (col.gameObject.CompareTag("Obstacle")){
            StartCoroutine(ObstacleFind());
        }
    }
    
    IEnumerator ObstacleFind(){
        yield return new WaitForSeconds(0.1f);
        SetVelocity(vitesse/2, 0);
        yield return new WaitForSeconds(0.5f);
        SetVelocity(vitesse, 0);
    }
        
    
}

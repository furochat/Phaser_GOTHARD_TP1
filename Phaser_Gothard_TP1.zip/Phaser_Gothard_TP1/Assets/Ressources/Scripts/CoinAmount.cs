﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Pour que interface joueur soit impacté par variables
using UnityEngine.UI;

public class CoinAmount : MonoBehaviour {

	// Use this for initialization
	void Start () {

        // ""  pour que logiciel comprenne que ce n'est pas un int mais une chaine de caractère string qui est renvoyé
        gameObject.GetComponent<Text>().text = PlayerPrefs.GetInt("CoinAmount") + "";

    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown("a"))
        {
            // "a" sauvegarde manuelle
            Debug.Log("Trésor Sauvegardé");
            PlayerPrefs.SetInt("CoinAmount", int.Parse(gameObject.GetComponent<Text>().text));
        }
	}
}

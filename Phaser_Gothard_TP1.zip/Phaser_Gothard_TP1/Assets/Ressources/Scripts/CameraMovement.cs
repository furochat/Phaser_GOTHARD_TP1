﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour {

    public GameObject character; 

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame f pour float -10 pour que la caméra ait assé de recul

	void Update () {
        transform.position = new Vector3 (character.transform.position.x + 2.5f ,0,-10);
		
	}
}
